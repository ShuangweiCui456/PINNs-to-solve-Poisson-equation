"""Compute gradients using reverse-mode autodiff."""
from .jacobian import Jacobian, Jacobians
from .. import tensor
import torch


class JacobianReverse(Jacobian):
    def __call__(self, i=None, j=None):
        super().__call__(i=i, j=j)
        # Compute a column is not supported in reverse mode, unless there is only one
        # output.
        if i is None:
            if self.dim_y > 1:
                raise NotImplementedError(
                    "Reverse-mode autodiff doesn't support computing a column."
                )
            i = 0
        
        ndim_y = tensor.ndim(self.ys)
        
        if ndim_y == 3:
            raise NotImplementedError(
                "Reverse-mode autodiff doesn't support 3D output"
            )

        # Compute J[i, :]
        if i not in self.J:
            # TODO: retain_graph=True has memory leak?
            y = self.ys[:, i : i + 1] if self.dim_y > 1 else self.ys
            self.J[i] = torch.autograd.grad(
                y, self.xs, grad_outputs=torch.ones_like(y), create_graph=True
            )[0]
            
            

        if j is None or self.dim_x == 1:
            return self.J[i]

        # Compute J[i, j]
        if (i, j) not in self.J:
            self.J[i, j] = self.J[i][:, j : j + 1]
        return self.J[i, j]


def jacobian(ys, xs, i=None, j=None):
    return jacobian._Jacobians(ys, xs, i=i, j=j)


jacobian._Jacobians = Jacobians(JacobianReverse)


class Hessian:
    """Compute `Hessian matrix <https://en.wikipedia.org/wiki/Hessian_matrix>`_ H as
    H[i, j] = d^2y / dx_i dx_j, where i,j = 0, ..., dim_x - 1.

    It is lazy evaluation, i.e., it only computes H[i, j] when needed.

    Args:
        ys: Output Tensor of shape (batch_size, dim_y).
        xs: Input Tensor of shape (batch_size, dim_x).
        component: `ys[:, component]` is used as y to compute the Hessian.
    """

    def __init__(self, ys, xs, component=0):
        dim_y = ys.shape[1]
        if component >= dim_y:
            raise ValueError(
                "The component of ys={} cannot be larger than the dimension={}.".format(
                    component, dim_y
                )
            )

        # There is no duplicate computation of grad_y.
        grad_y = jacobian(ys, xs, i=component, j=None)
        self.H = JacobianReverse(grad_y, xs)

    def __call__(self, i=0, j=0):
        """Returns H[`i`, `j`]."""
        return self.H(j, i)


class Hessians:
    """Compute multiple Hessians.

    A new instance will be created for a new pair of (output, input). For the (output,
    input) pair that has been computed before, it will reuse the previous instance,
    rather than creating a new one.
    """

    def __init__(self):
        self.Hs = {}

    def __call__(self, ys, xs, component=0, i=0, j=0):
        key = (ys, xs, component)
        if key not in self.Hs:
            self.Hs[key] = Hessian(ys, xs, component=component)
        return self.Hs[key](i, j)

    def clear(self):
        """Clear cached Hessians."""
        self.Hs = {}


def hessian(ys, xs, component=0, i=0, j=0):
    return hessian._Hessians(ys, xs, component=component, i=i, j=j)


hessian._Hessians = Hessians()


def clear():
    """Clear cached Jacobians and Hessians."""
    jacobian._Jacobians.clear()
    hessian._Hessians.clear()
