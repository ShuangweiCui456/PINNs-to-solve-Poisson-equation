"""Compute gradients using forward-mode autodiff."""

from .jacobian import Jacobian, Jacobians
import torch

class JacobianForward(Jacobian):
    def __call__(self, i=None, j=None):
        super().__call__(i=i, j=j)
        # Compute a row is not supported in forward mode, unless there is only one
        # input.
        if j is None:
            if self.dim_x > 1:
                raise NotImplementedError(
                    "Forward-mode autodiff doesn't support computing gradient."
                )
            j = 0

        # Compute J[:, j]
        if j not in self.J:
            
            
            
                # Here we use torch.func.jvp to compute the gradient of a function.
                # The implementation is similiar to backend JAX. Vectorization is not
                # not necessary but could be done through torch.func.vmap. We note that
                # torch.func, previously known as functorch, is integrated into PyTorch
                # and requires torch >= 2.1.
                # Another option is torch.autograd.functional.jvp. However, this
                # implementation computes the jvp by using the double backwards trick.
                # It is sometimes faster than torch.func.jvp because torch.func is
                # currently in beta. But we decided to go with torch.func.jvp.
            tangent = torch.zeros_like(self.xs)
            tangent[:, j] = 1
            grad_fn = lambda x: torch.func.jvp(self.ys[1], (x,), (tangent,))[1]
                # jvp by torch.autograd.functional.jvp
                # grad_fn = lambda x: torch.autograd.functional.jvp(self.ys[1], (x,), (tangent,), create_graph=True)[1]
            self.J[j] = (grad_fn(self.xs), grad_fn)
            
            

        if i is None or self.dim_y == 1:
            return self.J[j]

        # Compute J[i, j]
        if (i, j) not in self.J:
                # In backend tensorflow/pytorch/jax, a tuple of a tensor/tensor/array
                # and a callable is returned, so that it is consistent with the argument,
                # which is also a tuple. This is useful for further computation, e.g.,
                # Hessian.
            self.J[i, j] = (
                self.J[j][0][..., i : i + 1],
                lambda x: self.J[j][1](x)[i : i + 1],
            )
        return self.J[i, j]


def jacobian(ys, xs, i=None, j=None):
    return jacobian._Jacobians(ys, xs, i=i, j=j)


jacobian._Jacobians = Jacobians(JacobianForward)


def hessian(ys, xs, component=0, i=0, j=0):
    dys_xj = jacobian(ys, xs, i=None, j=j)
    return jacobian(dys_xj, xs, i=component, j=i)


def clear():
    """Clear cached Jacobians"""
    jacobian._Jacobians.clear()
