"""Operations which handle numpy and tensorflow.compat.v1 automatically."""

import numpy as np

from .. import tensor
from .. import config
from ..tensor import is_tensor
import torch

def istensorlist(values):
    return any(map(is_tensor, values))


def convert_to_array(value):
    """Convert a list of numpy arrays or tensors to a numpy array or a tensor."""
    if istensorlist(value):
        return torch.stack(value, axis=0)
    value = np.array(value)
    if value.dtype != config.real(np):
        return value.astype(config.real(np))
    return value


def hstack(tup):
    if not is_tensor(tup[0]) and isinstance(tup[0], list) and tup[0] == []:
        tup = list(tup)
        if istensorlist(tup[1:]):
            tup[0] = tensor.as_tensor([], dtype=config.real(torch))
        else:
            tup[0] = np.array([], dtype=config.real(np))
    return torch.cat(tup, 0) if is_tensor(tup[0]) else np.hstack(tup)