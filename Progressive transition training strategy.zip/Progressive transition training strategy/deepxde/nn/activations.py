import torch

def linear(x):
    return x

def get(identifier):
    if identifier is None:
        return linear
    if isinstance(identifier, str):
        return {
            "elu": torch.nn.functional.elu,
            "gelu": torch.nn.functional.gelu,
            "relu": torch.nn.functional.relu,
            "selu": torch.nn.functional.selu,
            "sigmoid": torch.nn.functional.sigmoid,
            "silu": torch.nn.functional.silu,
            "sin": torch.sin,
            "tanh": torch.tanh,
        }[identifier.lower()]
    if callable(identifier):
        return identifier
