"""Model extension for ZCS support"""

from .. import gradients as grad
from ..model import Model as BaseModel
from .. import tensor

class Model(BaseModel):
    """Derived `Model` class for ZCS support."""

    def __init__(self, data, net):
        super().__init__(data, net)
        # store ZCS parameters, sent to user for PDE calculation
        self.zcs_parameters = None



    def _compile_pytorch(self, lr, loss_fn, decay):
        """pytorch"""
        super()._compile_pytorch(lr, loss_fn, decay)

        def process_inputs_zcs(inputs):
            # get inputs
            branch_inputs, trunk_inputs = inputs

            # convert to tensors with grad disabled
            branch_inputs = tensor.as_tensor(branch_inputs)
            trunk_inputs = tensor.as_tensor(trunk_inputs)

            # create ZCS scalars
            n_dim_crds = trunk_inputs.shape[1]
            zcs_scalars = [
                tensor.as_tensor(0.0).requires_grad_() for _ in range(n_dim_crds)
            ]

            # add ZCS to truck inputs
            zcs_vector = tensor.stack(zcs_scalars)
            trunk_inputs = trunk_inputs + zcs_vector[None, :]

            # return inputs and ZCS scalars
            return (branch_inputs, trunk_inputs), {"leaves": zcs_scalars}

        def outputs_losses_zcs(training, inputs, targets, auxiliary_vars, losses_fn):
            # aux
            self.net.auxiliary_vars = None
            if auxiliary_vars is not None:
                self.net.auxiliary_vars = tensor.as_tensor(auxiliary_vars)

            # inputs
            inputs, self.zcs_parameters = process_inputs_zcs(inputs)

            # forward
            self.net.train(mode=training)
            outputs_ = self.net(inputs)

            # losses
            if targets is not None:
                targets = tensor.as_tensor(targets)
            losses = losses_fn(targets, outputs_, loss_fn, inputs, self)
            if not isinstance(losses, list):
                losses = [losses]
            losses = tensor.stack(losses)

            # TODO: regularization

            # weighted
            if self.loss_weights is not None:
                losses *= tensor.as_tensor(self.loss_weights)

            # clear cached gradients (actually not used with ZCS)
            grad.clear()
            return outputs_, losses

        def outputs_losses_train_zcs(inputs, targets, auxiliary_vars):
            return outputs_losses_zcs(
                True, inputs, targets, auxiliary_vars, self.data.losses_train
            )

        def outputs_losses_test_zcs(inputs, targets, auxiliary_vars):
            return outputs_losses_zcs(
                False, inputs, targets, auxiliary_vars, self.data.losses_test
            )

        def train_step_zcs(inputs, targets, auxiliary_vars):
            def closure():
                losses = outputs_losses_train_zcs(inputs, targets, auxiliary_vars)[1]
                total_loss = tensor.sum(losses)
                self.opt.zero_grad()
                total_loss.backward()
                return total_loss

            self.opt.step(closure)
            if self.lr_scheduler is not None:
                self.lr_scheduler.step()

        # overwrite callables
        self.outputs_losses_train = outputs_losses_train_zcs
        self.outputs_losses_test = outputs_losses_test_zcs
        self.train_step = train_step_zcs
