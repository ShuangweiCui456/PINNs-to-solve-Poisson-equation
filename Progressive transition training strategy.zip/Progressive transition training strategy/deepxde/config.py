import random
import torch
import numpy as np
from .real import Real

backend_name = "pytorch"

# Default float type
real = Real(32)
# Using mixed precision
mixed = False
# Random seed
random_seed = None
# XLA
xla_jit = False
# Automatic differentiation
autodiff = "reverse"
rank = 0

def default_float():
    """Returns the default float type, as a string."""
    if real.precision == 64:
        return "float64"
    elif real.precision == 32:
        return "float32"
    elif real.precision == 16:
        return "float16"


def set_default_float(value):
    """Sets the default float type.

    The default floating point type is 'float32'. Mixed precision uses the method in the paper:
    `J. Hayford, J. Goldman-Wetzler, E. Wang, & L. Lu. Speeding up and reducing memory usage for scientific machine learning via mixed precision.
    Computer Methods in Applied Mechanics and Engineering, 428, 117093, 2024 <https://doi.org/10.1016/j.cma.2024.117093>`_.

    Args:
        value (String): 'float16', 'float32', 'float64', or 'mixed' (mixed precision).
    """
    global mixed
    if value == "float16":
        print("Set the default float type to float16")
        real.set_float16()
    elif value == "float32":
        print("Set the default float type to float32")
        real.set_float32()
    elif value == "float64":
        print("Set the default float type to float64")
        real.set_float64()
    elif value == "mixed":
        print("Set the float type to mixed precision of float16 and float32")
        mixed = True
        if backend_name == "pytorch":
            # Use float16 during the forward and backward passes, but store in float32
            real.set_float32()
    else:
        raise ValueError(f"{value} not supported in deepXDE")
    if backend_name == "pytorch":
        torch.set_default_dtype(real(torch))


def set_random_seed(seed):
    """Sets all random seeds for the program (Python random, NumPy, and backend), and
    configures the program to run deterministically.

    You can use this to make the program fully deterministic. This means that if the
    program is run multiple times with the same inputs on the same hardware, it will
    have the exact same outputs each time. This is useful for debugging models, and for
    obtaining fully reproducible results.

    - For backend TensorFlow 2.x: Results might change if you run the model several
      times in the same terminal.

    Warning:
        Note that determinism in general comes at the expense of lower performance and
        so your model may run slower when determinism is enabled.

    Args:
        seed (int): The desired seed.
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    global random_seed
    random_seed = seed